'use strict'

let assessment_btn = document.querySelector(".assessment__form");
let form_close =  document.querySelector(".close_btn")
let form = document.querySelector("form")
let overlay = document.querySelector(".overlay")

assessment_btn.addEventListener("click",()=>{
    form.style.display = "block"
    form.style.animation = "slide-in-bottom 0.5s ease both"
    overlay.style.display = "block"
   
})

overlay.addEventListener('click',()=>{
    form.style.animation = "slide-out-bottom 0.5s  ease  both"
    overlay.style.display = "none"
    setTimeout(()=>{
        form.style.display = "none"
    },400)
})
form_close.addEventListener("click",()=>{
    form.style.animation = "slide-out-bottom 0.5s ease both"
    overlay.style.display = "none"
    setTimeout(()=>{
        form.style.display = "none"
    },400)
     
})


// for mobile view

let mobile_close = document.querySelector(".mobile_close");
let mobile_overlay = document.querySelector(".mobile__overlay");
let mobile_sidebar = document.querySelector(".mobile__view-sidebar") 
let mobile_view_btn = document.querySelector(".mobile__view-btn")


mobile_view_btn.addEventListener("click",()=>{
    mobile_overlay.style.display ="block"
    mobile_sidebar.style.animation = "left-slide-in 0.2s ease-out both"
    mobile_sidebar.style.display = "block"
    
})

mobile_close.addEventListener("click",()=>{
   

    mobile_sidebar.style.animation = "left-slide-out 0.4s ease-out both"
    mobile_overlay.style.display ="none"
  
})

mobile_overlay.addEventListener("click",()=>{
    mobile_sidebar.style.animation = "left-slide-out 0.4s ease-out both"
    mobile_overlay.style.display ="none"
  
})




// for mobileview toggle


let mobile_view_stats = document.querySelector(".mobile__view-stats")
let chart_icon = document.querySelector(".mobile__stat-toggle")

$(document).ready(function(){
    $(mobile_view_stats).hide()

    $(chart_icon).click(function(){
        console.log("clicked")
        $(mobile_view_stats).slideToggle(300)
    })

})